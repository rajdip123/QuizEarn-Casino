import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import LandingWrapper from './LandingWrapper.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <LandingWrapper />
  </StrictMode>,
);
